import org.panthercode.arctic.core.collections.VersionMap;
import org.panthercode.arctic.core.helper.identity.IdentityInfo;
import org.panthercode.arctic.core.helper.version.VersionInfo;
import org.panthercode.arctic.core.processing.ProcessException;
import org.panthercode.arctic.core.processing.modules.RootModule;
import org.panthercode.arctic.core.processing.modules.impl.Step;
import org.panthercode.arctic.core.resources.Resource;
import org.panthercode.arctic.core.settings.Context;

/**
 * Created by architect on 18.01.17.
 */
@RootModule
@IdentityInfo(name = "FanceModule", group = "Modules")
@VersionInfo(major = 0, minor = 1)
public class FancyModule extends Step {
    @Override
    public boolean step() throws ProcessException {
        Context context = this.getContext();

        //Better: use ResourceAllocator class
        VersionMap<String, Resource> resourcePool = (VersionMap<String, Resource>) context.get("resources");

        System.out.println("Module: I want a resource named \'FancyTerminalEmulator\'");

        Resource terminal = resourcePool.get("FancyTerminalEmulator");


        if (terminal != null) {
            try {
                System.out.println("Module: Resource? Check.");

                terminal.acquire();

                System.out.println("Module: Aquire resource? Check.");

                if (context.containsKey("question")) {
                    terminal.execute("print", Void.class, context.get("question"));
                } else {
                    System.out.println("No question to print.");
                }

                if (context.containsKey("answer")) {
                    terminal.execute("print", Void.class, context.get("answer"));
                } else {
                    System.out.println("No answer to print.");
                }

                terminal.release();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            return true;
        }

        return false;
    }

    @Override
    public boolean stop() throws ProcessException {
        return false;
    }

    @Override
    public boolean reset() throws ProcessException {
        return false;
    }

    @Override
    public Step copy() throws UnsupportedOperationException {
        return null;
    }
}
