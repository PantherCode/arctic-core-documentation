import org.panthercode.arctic.core.cli.CliParameter;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by PantherCode on 18.01.17.
 */
public class DirectoryWatcherSettings {

    private Path path;

    private int delayTimeInMillis;

    public DirectoryWatcherSettings() {
    }

    //TODO:               replace default value with correct Path -----v
    @CliParameter(name = "path", shortName = 'p', defaultValue = "<correct path>", description = "path for directory watcher", hasValue = true)
    public void setPath(String path) {
        this.path = Paths.get(path);
    }

    public Path getPath() {
        return this.path;
    }

    @CliParameter(name = "delay", shortName = 'd', defaultValue = "1234", description = "delay time for looping", hasValue = true, type = Integer.class)
    public void setDelay(int delayInMillis) {
        this.delayTimeInMillis = delayInMillis;
    }

    public int getDelayTimeInMillis() {
        return this.delayTimeInMillis;
    }
}
