import org.panthercode.arctic.core.helper.identity.IdentityInfo;
import org.panthercode.arctic.core.helper.version.VersionInfo;
import org.panthercode.arctic.core.resources.AbstractResource;
import org.panthercode.arctic.core.resources.Resource;

/**
 * Created by PantherCode on 18.01.17.
 */
@IdentityInfo(name = "FancyTerminalEmulator", group = "Terminal")
@VersionInfo(major = 0, minor = 1)
public class FancyTerminalEmulator extends AbstractResource {

    public FancyTerminalEmulator() {
    }

    public void print(String message) {
        System.out.println("Terminal: " + message);
    }

    @Override
    public Resource copy() {
        return null;
    }
}
