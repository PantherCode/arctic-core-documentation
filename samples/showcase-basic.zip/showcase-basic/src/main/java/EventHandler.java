import org.apache.commons.io.FileUtils;
import org.panthercode.arctic.core.helper.event.Handler;
import org.panthercode.arctic.core.io.DirectoryWatcherEvent;
import org.panthercode.arctic.core.json.JsonUtils;
import org.panthercode.arctic.core.processing.modules.Module;
import org.panthercode.arctic.core.processing.modules.RootModule;
import org.panthercode.arctic.core.reflect.ReflectionUtils;
import org.panthercode.arctic.core.settings.Context;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static java.nio.file.StandardWatchEventKinds.ENTRY_MODIFY;

/**
 * Created by PantherCode on 18.01.17.
 */
public class EventHandler implements Handler<DirectoryWatcherEvent> {

    @Override
    public void handle(DirectoryWatcherEvent directoryWatcherEvent) {
        System.out.println("Something happens: " + directoryWatcherEvent.kind() + " at " + directoryWatcherEvent.source());

        if (Files.exists(directoryWatcherEvent.source()) && !Files.isDirectory(directoryWatcherEvent.source())) {

            String[] parts = directoryWatcherEvent.source().getFileName().toString().split("\\.");
            String filename = parts[0];
            String extension = parts[1];

            Path parentPath = directoryWatcherEvent.source().getParent();

            if (directoryWatcherEvent.kind() == ENTRY_MODIFY && extension.equals("jar")) {
                System.out.println("Yippie! A .jar archive. Who are you?");

                try {
                    Module module = this.getModule(directoryWatcherEvent.source());

                    System.out.println(module.identity());
                    System.out.println(module.version());

                    Context context = new Context();

                    if (Files.exists(parentPath.resolve(filename + ".json"))) {
                        context = this.getContext(parentPath.resolve(filename + ".json"));
                    }

                    context.put("resources", MyApplication.current(MyApplication.class).resourcePool());

                    System.out.println("Start module.");

                    this.magic(module, context);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } else if (directoryWatcherEvent.kind() == ENTRY_MODIFY && extension.equals("json")) {
                System.out.println("I found a configuration file.");
                try {
                    if (Files.exists(parentPath.resolve(filename + ".jar"))) {
                        Module module = this.getModule(parentPath.resolve(filename + ".jar"));

                        Context context = this.getContext(directoryWatcherEvent.source());

                        context.put("resources", MyApplication.current(MyApplication.class).resourcePool());

                        this.magic(module, context);
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    private Module getModule(Path path) throws IOException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        List<Class<?>> classes = ReflectionUtils.extractClassesFromJar(path);
        List<Class<?>> filterClassList = ReflectionUtils.filterClassListByAnnotation(classes, RootModule.class);

        if (filterClassList.size() > 0) {
            Class<?> moduleClass = filterClassList.get(0);

            return (Module) moduleClass.getConstructor().newInstance();
        }

        throw new RuntimeException("No RootModule found.");
    }

    private Context getContext(Path path) throws IOException {
        String json = FileUtils.readFileToString(path.toFile(), "utf-8");

        return JsonUtils.fromJson(json, Context.class);
    }

    private void magic(Module module, Context context) {
        module.setContext(context);

        System.out.println("Module successful: " + module.start());
    }


}
