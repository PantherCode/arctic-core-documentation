import org.panthercode.arctic.core.cli.CommandLineBinder;
import org.panthercode.arctic.core.collections.VersionMap;
import org.panthercode.arctic.core.helper.identity.IdentityInfo;
import org.panthercode.arctic.core.helper.version.VersionInfo;
import org.panthercode.arctic.core.io.Directory;
import org.panthercode.arctic.core.io.DirectoryWatcher;
import org.panthercode.arctic.core.resources.Resource;
import org.panthercode.arctic.core.runtime.Application;
import org.panthercode.arctic.core.runtime.ShutdownException;

/**
 * Created by PantherCode on 18.01.17.
 *
 * TODO: Before starting application replace default path value in DirectoryWatcherSettings class with correct one
 */
@IdentityInfo(name = "MySupperApplication", group = "Ultra Application")
@VersionInfo(major = 42, minor = 13)
public class MyApplication extends Application {

    private VersionMap<String, Resource> resourcePool = new VersionMap<>();

    public static void main(String[] args) {
        MyApplication.startUp(new MyApplication(), args);
    }

    public void run(String[] args) throws Exception {
        System.out.println("Hi user, I'm a demo app.");

        System.out.println("My identity: " + this.identity());
        System.out.println("My version : " + this.version());

        FancyTerminalEmulator terminal = new FancyTerminalEmulator();

        resourcePool.put(terminal.identity().getName(), terminal);

        CommandLineBinder binder = CommandLineBinder.create().
                bind(DirectoryWatcherSettings.class)
                .parse(args);

        DirectoryWatcherSettings settings = binder.from(DirectoryWatcherSettings.class, new DirectoryWatcherSettings());

        System.out.println("Path to observe: " + settings.getPath().toString());
        System.out.println("Delay time: " + settings.getDelayTimeInMillis() + " ms");

        DirectoryWatcher watcher = DirectoryWatcher.create(settings.getDelayTimeInMillis());

        watcher.registerTree(Directory.open(settings.getPath()), new EventHandler());

        watcher.start();
    }

    public VersionMap resourcePool() {
        return this.resourcePool;
    }

    public void exceptionHandler(Exception e) {
        System.out.println("There is an exception occurred: " + e.getMessage());

    }

    public void shutdownHandler(ShutdownException e) {
        System.out.println("The application want to shutdown: " + e.getMessage());
    }
}
